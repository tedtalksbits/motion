# Password Manager

## My passwords

[Passwords](Passwords%201a8aad3ced76810b8926eaa626a22546.csv)

## Password generator

[https://www.nodi.so/widgets/embed/public/password-generator](https://www.nodi.so/widgets/embed/public/password-generator)